Firstly, before asking questions, you should look at this url:
http://knowyourmeme.com/memes/doge
I decided to make a more fun and silly website. The simple
design is for the sake of the joke, and I think it came out
pretty well. As for pictures and comic sans font, they came 
from online resources and paint.NET. The description json file
has a bunch of descriptive words and the pairing they DON'T
match with. I figured there was less cases for exceptions then
not, so it would be more data effecient. I went for an object 
oriented javascript approach, mostly because it sounded like 
fun. I regret this decision immensely,but I did learn a lot as 
a result of it. 